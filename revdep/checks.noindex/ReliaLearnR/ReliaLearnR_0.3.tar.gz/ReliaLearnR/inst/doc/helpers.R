## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, include=FALSE-----------------------------------------------------
library(ReliaLearnR)

## ----echo=TRUE, results='asis'------------------------------------------------
result <- rel(5, 3 * 365)
cat(result)

## ----echo=TRUE, results='asis'------------------------------------------------
result <- avail(5 + 14, 3 * 365)
cat(result)

## ----echo=TRUE, results='asis'------------------------------------------------
result <- mean(c(5, 10, 15, 8, 12))
cat(result)

## ----echo=TRUE, results='asis'------------------------------------------------
result <- mttf(5 + 14, 3 * 365)
cat(result)

## ----echo=TRUE, results='asis'------------------------------------------------
result <- mtbf(5, 45000)
cat(result)

## ----echo=TRUE, results='asis'------------------------------------------------
result <- fr(75, 100 * 5000)
cat(result)

## ----echo=TRUE, results='asis'------------------------------------------------
result <- 1 - pexp(5, 0.1)
cat(result)

## ----echo=TRUE, results='asis'------------------------------------------------
result <- qexp(0.1, 0.1)
cat(result)

